from __future__ import annotations

from typing import Iterable, Tuple

import numpy as np


def balanced_class_weights(labels: Iterable[int], num_classes: int) -> Tuple[np.ndarray, np.ndarray]:
    """Return class counts and sklearn-style balanced CE weights.

    For class ``c``, ``weight[c] = n_samples / (num_classes * count[c])``.
    Callers must pass labels from the current fold's training subset only.
    """
    labels_array = np.asarray(list(labels), dtype=np.int64)
    if labels_array.ndim != 1 or labels_array.size == 0:
        raise ValueError("Class weights require a non-empty one-dimensional label sequence")
    if num_classes < 2:
        raise ValueError("num_classes must be at least two")
    if np.any(labels_array < 0) or np.any(labels_array >= num_classes):
        raise ValueError(f"Labels must be integers in [0, {num_classes - 1}]")
    counts = np.bincount(labels_array, minlength=num_classes)
    if np.any(counts == 0):
        missing = np.flatnonzero(counts == 0).tolist()
        raise ValueError(f"Fold training subset is missing class(es): {missing}")
    weights = labels_array.size / (float(num_classes) * counts.astype(np.float64))
    return counts.astype(np.int64), weights

