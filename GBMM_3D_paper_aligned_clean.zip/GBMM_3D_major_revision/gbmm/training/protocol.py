from sklearn.model_selection import StratifiedKFold
import numpy as np


def patient_folds(records, folds=5, seed=104):
    if any(r.split != 'train' for r in records):
        raise ValueError('Only training-cohort patients can enter cross-validation.')
    ids = [r.image_patient_id for r in records]
    if len(ids) != len(set(ids)):
        raise ValueError('Patients must be unique before splitting.')
    labels = np.asarray([r.label for r in records])
    if set(labels) != {0, 1} or min(np.bincount(labels)) < folds:
        raise ValueError('Each class needs at least five patients for stratified five-fold CV.')
    splitter = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
    for fold, (train_index, heldout_index) in enumerate(splitter.split(np.zeros(len(labels)), labels), 1):
        yield fold, [records[i] for i in train_index], [records[i] for i in heldout_index]
