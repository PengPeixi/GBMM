from __future__ import annotations
import copy
import uuid
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from gbmm.config import require_private_paths, require_threshold_policy
from gbmm.data.dataset import GBMMDataset
from gbmm.data.manifest import FeatureRepository, load_manifest
from gbmm.evaluation.metrics import safe_auc
from gbmm.evaluation.threshold import select_oof_threshold
from gbmm.models import GBMM3D
from gbmm.training.ema import cosine_ema_momentum, initialize_teacher, update_ema
from gbmm.training.losses import balanced_class_weights
from gbmm.training.protocol import patient_folds
from gbmm.utils.io import atomic_csv_dump, atomic_json_dump, ensure_dir
from gbmm.utils.seed import seed_everything


def resolve_device(name):
    device = torch.device(name)
    if device.type == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA is unavailable. Install the matching GPU stack or explicitly use --device cpu.')
    return device


def _loader(dataset, batch_size, workers, shuffle, seed):
    generator = torch.Generator().manual_seed(seed)
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, num_workers=workers,
                      pin_memory=torch.cuda.is_available(), drop_last=False, generator=generator)


def train_resolution_phase(student, loader, optimizer, criterion, device):
    student.train()
    total, count = 0.0, 0
    for batch in loader:
        optimizer.zero_grad(set_to_none=True)
        logits, _ = student(*(batch[k].to(device, non_blocking=True) for k in ('image', 'mask', 'radiomics', 'clinical')))
        target = batch['label'].to(device, non_blocking=True)
        loss = criterion(logits, target)
        if not torch.isfinite(loss):
            raise FloatingPointError('Non-finite weighted cross-entropy loss.')
        loss.backward()
        optimizer.step()
        total += float(loss.detach()) * len(target)
        count += len(target)
    if not count:
        raise ValueError('Empty training phase.')
    return total / count


@torch.no_grad()
def predict_resolution(model, loader, device, resolution):
    model.eval()
    rows = []
    for batch in loader:
        logits, _ = model(*(batch[k].to(device, non_blocking=True) for k in ('image', 'mask', 'radiomics', 'clinical')))
        p = torch.softmax(logits, dim=1)[:, 1].cpu().numpy()
        if not np.isfinite(p).all():
            raise FloatingPointError('Non-finite prediction probability.')
        for patient, scanner, label, probability in zip(batch['patient_id'], batch['scanner'], batch['label'].tolist(), p):
            rows.append({'patient_id': str(patient), 'scanner': str(scanner), 'label': int(label),
                         f'probability_{resolution}': float(probability)})
    return pd.DataFrame(rows)


def _save_checkpoint(path, model, config, repository, fold, epoch, run_id):
    payload = {
        'run_id': run_id, 'fold': fold, 'epoch': epoch, 'kind': 'ema_teacher',
        'architecture_contract': model.architecture_contract,
        'model_config': dict(config['model']), 'data_config': dict(config['data']),
        'radiomics_dim': repository.radiomics_dim, 'clinical_dim': repository.clinical_dim,
        'radiomics_columns': repository.radiomics_columns, 'clinical_columns': repository.clinical_columns,
        'feature_preprocessing': repository.preprocessing,
        'checkpoint_selection': 'final_epoch', 'state_dict': model.state_dict(),
    }
    temporary = path.with_suffix('.tmp')
    torch.save(payload, temporary)
    temporary.replace(path)


def train_fold(fold, train_records, heldout_records, repository, config, device, run_id):
    # Reset the manuscript seed for each independent fold.
    fold_seed = int(config['seed'])
    t = config['training']
    seed_everything(fold_seed, t['deterministic'], t['enforce_deterministic_algorithms'])
    fold_dir = ensure_dir(Path(config['paths']['output_root']) / 'checkpoints' / f'fold_{fold}')
    repository.fit_preprocessing(train_records)
    counts, weights = balanced_class_weights([r.label for r in train_records], 2)
    atomic_json_dump({'source': 'fold_training_subset_only', 'counts': counts.tolist(),
                      'weights': weights.tolist(), 'seed': fold_seed}, fold_dir / 'class_weights.json')
    student = GBMM3D(config['model'], repository.radiomics_dim, repository.clinical_dim).to(device)
    teacher = copy.deepcopy(student)
    initialize_teacher(student, teacher)
    optimizer = torch.optim.AdamW(student.parameters(), lr=t['learning_rate'],
                                  betas=tuple(t['betas']), weight_decay=t['weight_decay'])
    criterion = torch.nn.CrossEntropyLoss(weight=torch.tensor(weights, dtype=torch.float32, device=device))
    loaders = {r: _loader(GBMMDataset(train_records, r, repository, config), t['batch_size'],
                         t['num_workers'], True, fold_seed + i) for i, r in enumerate(('1mm', '5mm'))}
    log = []
    for epoch in range(1, t['epochs'] + 1):
        losses = {r: train_resolution_phase(student, loaders[r], optimizer, criterion, device)
                  for r in ('1mm', '5mm')}
        momentum = cosine_ema_momentum(t['ema_momentum_start'], t['ema_momentum_end'], epoch - 1, t['epochs'])
        update_ema(student, teacher, momentum)
        log.append({'epoch': epoch, 'loss_1mm': losses['1mm'], 'loss_5mm': losses['5mm'], 'ema_momentum': momentum})
        atomic_csv_dump(pd.DataFrame(log), fold_dir / 'epoch_log.csv')
        print(f'fold={fold}/5 epoch={epoch}/{t["epochs"]} loss_1mm={losses["1mm"]:.5f} loss_5mm={losses["5mm"]:.5f}', flush=True)
    _save_checkpoint(fold_dir / 'teacher_final.pt', teacher, config, repository, fold, t['epochs'], run_id)
    frames = []
    for i, r in enumerate(('1mm', '5mm')):
        loader = _loader(GBMMDataset(heldout_records, r, repository, config), t['batch_size'], t['num_workers'], False, fold_seed + i)
        frame = predict_resolution(teacher, loader, device, r).rename(columns={f'probability_{r}': 'probability'})
        frame['fold'], frame['resolution'] = fold, r
        frames.append(frame)
        print(f'fold={fold} heldout={r} auc={safe_auc(frame.label, frame.probability):.6f}', flush=True)
    result = pd.concat(frames, ignore_index=True)
    atomic_csv_dump(result, fold_dir / 'oof_predictions.csv')
    del student, teacher, optimizer
    if device.type == 'cuda':
        torch.cuda.empty_cache()
    return result


def run_cross_validation(config, device_name='cuda:0'):
    require_private_paths(config)
    require_threshold_policy(config)
    device = resolve_device(device_name)
    records = [r for r in load_manifest(config['paths']['manifest']) if r.split == 'train']
    repository = FeatureRepository(config, records)
    # Validate all fold splits before creating any output.
    folds = list(patient_folds(records, config['training']['folds'], config['seed']))
    output = ensure_dir(config['paths']['output_root'])
    if any(output.iterdir()):
        raise FileExistsError('Output directory must be empty to avoid mixing runs; choose --output-root.')
    run_id = uuid.uuid4().hex
    # Frozen configuration excludes private locations but captures every protocol choice.
    atomic_json_dump({'run_id': run_id, 'seed': config['seed'], 'training': config['training'],
                      'model': config['model'], 'data': config['data'], 'evaluation': config['evaluation']}, output / 'run_protocol.json')
    oof = pd.concat([train_fold(f, tr, va, repository, config, device, run_id) for f, tr, va in folds], ignore_index=True)
    if oof.duplicated(['patient_id', 'resolution']).any() or len(oof) != 2 * len(records):
        raise RuntimeError('OOF must contain one prediction per patient per resolution.')
    if (oof.groupby('patient_id')['fold'].nunique() != 1).any():
        raise RuntimeError('Patient folds differ between resolutions.')
    atomic_csv_dump(oof, output / 'oof_predictions.csv')
    atomic_csv_dump(oof[['patient_id', 'fold', 'resolution']], output / 'fold_assignments.csv')
    policy = config['evaluation']['threshold']
    selected = oof[oof['resolution'] == policy['oof_resolution']]
    frozen = select_oof_threshold(selected.label, selected.probability, policy['specificity_weight'], policy['minimum_specificity'])
    frozen.update({'run_id': run_id, 'oof_resolution': policy['oof_resolution'], 'folds': 5, 'epoch': config['training']['epochs'], 'probability_space': 'raw_softmax'})
    atomic_json_dump(frozen, output / 'threshold.json')
    atomic_json_dump({'run_id': run_id, 'folds_completed': 5, 'epoch': config['training']['epochs']}, output / 'training_complete.json')
    return oof
