from __future__ import annotations

import math

import torch


def cosine_ema_momentum(start: float, end: float, step: int, total_steps: int) -> float:
    if total_steps <= 1:
        return float(end)
    progress = min(max(step, 0), total_steps - 1) / float(total_steps - 1)
    return float(end - 0.5 * (end - start) * (1.0 + math.cos(math.pi * progress)))


@torch.no_grad()
def update_ema(student, teacher, momentum: float) -> None:
    student_parameters = dict(student.named_parameters())
    for name, teacher_parameter in teacher.named_parameters():
        teacher_parameter.mul_(momentum).add_(student_parameters[name].detach(), alpha=1.0 - momentum)
    student_buffers = dict(student.named_buffers())
    for name, teacher_buffer in teacher.named_buffers():
        source = student_buffers[name].detach()
        if teacher_buffer.dtype.is_floating_point:
            teacher_buffer.mul_(momentum).add_(source, alpha=1.0 - momentum)
        else:
            teacher_buffer.copy_(source)


def initialize_teacher(student, teacher) -> None:
    teacher.load_state_dict(student.state_dict())
    teacher.eval()
    for parameter in teacher.parameters():
        parameter.requires_grad_(False)

