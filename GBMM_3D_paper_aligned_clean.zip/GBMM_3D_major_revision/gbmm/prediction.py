from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from gbmm.config import require_private_paths
from gbmm.data.manifest import FeatureRepository, load_manifest
from gbmm.evaluation.threshold import TRAINING_OOF_SOURCE
from gbmm.utils.io import atomic_csv_dump


def combine_fold_predictions(frames):
    """Align patient IDs strictly; arithmetic mean of five equal-weight teachers."""
    if len(frames) != 5:
        raise ValueError('Exactly five fold predictions are required.')
    result = None
    for fold, frame in enumerate(frames, 1):
        if frame['patient_id'].duplicated().any() or frame.empty:
            raise ValueError('Empty or duplicate fold predictions.')
        values = frame['probability'].to_numpy(float)
        if not np.isfinite(values).all() or ((values < 0) | (values > 1)).any():
            raise ValueError('Invalid fold probabilities.')
        current = frame.rename(columns={'probability': f'fold_{fold}_probability'})
        if result is None:
            result = current.copy()
        else:
            old_n = len(result)
            result = result.merge(current, on=['patient_id', 'scanner', 'label'], how='inner', validate='one_to_one')
            if len(result) != old_n or len(result) != len(current):
                raise ValueError('Fold patient IDs/labels do not agree.')
    result['probability'] = result[[f'fold_{f}_probability' for f in range(1, 6)]].mean(axis=1)
    return result


def load_run(output):
    def read(name):
        with (Path(output) / name).open(encoding='utf-8') as handle:
            return json.load(handle)
    complete, threshold, protocol = (read(n) for n in ('training_complete.json', 'threshold.json', 'run_protocol.json'))
    if len({x['run_id'] for x in (complete, threshold, protocol)}) != 1 or complete['folds_completed'] != 5:
        raise ValueError('Incomplete or mixed training runs.')
    if threshold['source'] != TRAINING_OOF_SOURCE or threshold['probability_space'] != 'raw_softmax':
        raise ValueError('Threshold was not frozen from raw training OOF probabilities.')
    if not np.isfinite(threshold['threshold']) or not 0 <= threshold['threshold'] <= np.nextafter(1., np.inf):
        raise ValueError('Invalid frozen threshold.')
    return complete, threshold, protocol


def predict_ensemble(config, split, device_name='cuda:0'):
    # Lazy deep-learning imports keep CLI help and array-based validation usable on CPU hosts.
    import torch
    from gbmm.data.dataset import GBMMDataset
    from gbmm.models import ARCHITECTURE_CONTRACT, GBMM3D
    from gbmm.training.engine import _loader, predict_resolution, resolve_device
    require_private_paths(config)
    if split not in ('internal', 'external'):
        raise ValueError('Only internal/external cohorts are test targets.')
    output = Path(config['paths']['output_root'])
    complete, threshold, protocol = load_run(output)
    for key in ('data', 'model'):
        if config[key] != protocol[key]:
            raise ValueError(f'Testing {key} configuration differs from the frozen training protocol.')
    device = resolve_device(device_name)
    records = [r for r in load_manifest(config['paths']['manifest']) if r.split == split]
    if not records:
        raise ValueError('Requested cohort is empty.')
    repository = FeatureRepository(config, records)
    resolutions = config['evaluation']['resolutions'][split]
    predictions = {r: [] for r in resolutions}
    for fold in range(1, 6):
        path = output / 'checkpoints' / f'fold_{fold}' / 'teacher_final.pt'
        checkpoint = torch.load(path, map_location='cpu', weights_only=True)
        if checkpoint['run_id'] != complete['run_id'] or checkpoint['fold'] != fold or checkpoint['epoch'] != 40 or checkpoint['kind'] != 'ema_teacher':
            raise ValueError('Checkpoint does not belong to the completed five-fold run.')
        if checkpoint['architecture_contract'] != ARCHITECTURE_CONTRACT:
            raise ValueError('Incompatible checkpoint architecture; retrain with this project.')
        if checkpoint['model_config'] != config['model'] or checkpoint['data_config'] != config['data']:
            raise ValueError('Checkpoint configuration mismatch.')
        if checkpoint['radiomics_columns'] != repository.radiomics_columns or checkpoint['clinical_columns'] != repository.clinical_columns:
            raise ValueError('Training/testing feature columns or order differ.')
        repository.set_preprocessing(checkpoint['feature_preprocessing'])
        model = GBMM3D(checkpoint['model_config'], checkpoint['radiomics_dim'], checkpoint['clinical_dim']).to(device)
        model.load_state_dict(checkpoint['state_dict'], strict=True)
        for r in resolutions:
            loader = _loader(GBMMDataset(records, r, repository, config), config['training']['batch_size'],
                             config['training']['num_workers'], False, config['seed'])
            predictions[r].append(predict_resolution(model, loader, device, r).rename(columns={f'probability_{r}': 'probability'}))
        del model, checkpoint
        if device.type == 'cuda':
            torch.cuda.empty_cache()
    results = {}
    for resolution, frames in predictions.items():
        frame = combine_fold_predictions(frames)
        frame['prediction'] = (frame['probability'] >= threshold['threshold']).astype(int)
        frame['threshold'] = threshold['threshold']
        frame['cohort'], frame['resolution'], frame['run_id'] = split, resolution, complete['run_id']
        atomic_csv_dump(frame, output / f'{split}_predictions_{resolution}.csv')
        results[resolution] = frame
    return results
