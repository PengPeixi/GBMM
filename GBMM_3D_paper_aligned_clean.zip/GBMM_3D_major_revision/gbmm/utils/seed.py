from __future__ import annotations

import os
import random

import numpy as np


def seed_everything(
    seed: int,
    deterministic: bool = True,
    enforce_deterministic_algorithms: bool = False,
) -> None:
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    try:
        import torch
    except ImportError:
        return
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = bool(deterministic)
    torch.backends.cudnn.benchmark = False
    try:
        # False is intentional: seeds and deterministic CuDNN remain enabled,
        # while CuBLAS operations unsupported by the strict global gate no
        # longer emit the CUDA >= 10.2 deterministic-algorithm warning.
        torch.use_deterministic_algorithms(bool(enforce_deterministic_algorithms))
    except AttributeError:
        pass
