from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any, Union

import pandas as pd


def ensure_dir(path: Union[str, Path]) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def atomic_json_dump(data: Any, path: Union[str, Path]) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2, allow_nan=False)
        tmp = handle.name
    os.replace(tmp, path)


def atomic_csv_dump(frame: pd.DataFrame, path: Union[str, Path]) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False, newline="") as handle:
        frame.to_csv(handle, index=False)
        tmp = handle.name
    os.replace(tmp, path)
