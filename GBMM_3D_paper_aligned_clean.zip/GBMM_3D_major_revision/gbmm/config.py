from __future__ import annotations
from copy import deepcopy
from pathlib import Path
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def load_config(path='config/default.yaml'):
    path = Path(path).expanduser()
    if not path.is_absolute():
        path = PROJECT_ROOT / path
    with path.open(encoding='utf-8') as handle:
        config = yaml.safe_load(handle)
    for key, value in config['paths'].items():
        if value:
            p = Path(value).expanduser()
            config['paths'][key] = str((PROJECT_ROOT / p).resolve() if not p.is_absolute() else p.resolve())
    validate_config(config)
    return config


def validate_config(config):
    t, m, d, e = (config[k] for k in ('training', 'model', 'data', 'evaluation'))
    if t['folds'] != 5 or t['epochs'] != 40:
        raise ValueError('The manuscript protocol requires 5 folds and 40 epochs.')
    if int(config['seed']) != 104:
        raise ValueError('The manuscript random seed is 104.')
    if t['learning_rate'] != 0.001 or t['weight_decay'] != 0.00005 or t['betas'][0] != 0.9:
        raise ValueError('Use the manuscript AdamW learning rate, weight decay and beta1.')
    if len(t['betas']) != 2 or not all(0 <= v < 1 for v in t['betas']):
        raise ValueError('AdamW betas must be in [0, 1).')
    if not 0 <= t['ema_momentum_start'] <= t['ema_momentum_end'] < 1:
        raise ValueError('Invalid EMA momentum range.')
    if t['batch_size'] < 1 or t['num_workers'] < 0:
        raise ValueError('Invalid DataLoader settings.')
    if d['input_size'] != [64, 64, 64] or (d['intensity_min'], d['intensity_max']) != (63.18, 106.23):
        raise ValueError('Use the manuscript 64-cubed input and HU interval.')
    if m['image_size'] != 64 or m['patch_size'] != 16 or m['num_classes'] != 2:
        raise ValueError('Use 64 patches and binary classification.')
    if m['layer_norm'] is not True or m['batch_norm'] is not False:
        raise ValueError('The supplementary architecture describes LayerNorm.')
    if not isinstance(d['features_already_standardized'], bool):
        raise ValueError('features_already_standardized must be true or false.')
    threshold = e['threshold']
    if threshold['oof_resolution'] not in ('1mm', '5mm'):
        raise ValueError('threshold.oof_resolution must be 1mm or 5mm.')
    w, s = threshold['specificity_weight'], threshold['minimum_specificity']
    if w is not None and (not isinstance(w, (int, float)) or not 0 < w < float('inf')):
        raise ValueError('specificity_weight must be positive and finite.')
    if s is not None and (not isinstance(s, (int, float)) or not 0 <= s <= 1):
        raise ValueError('minimum_specificity must be in [0, 1].')
    if e['resolutions'] != {'internal': ['1mm', '5mm'], 'external': ['5mm']}:
        raise ValueError('Use internal 1mm/5mm and external 5mm, with no mixed inputs.')
    if e['bootstrap_iterations'] < 2 or e['calibration_bins'] < 2:
        raise ValueError('Invalid evaluation bootstrap/bin count.')
    if not 0 < e['dca_threshold_min'] < e['dca_threshold_max'] < 1 or e['dca_threshold_step'] <= 0:
        raise ValueError('DCA thresholds must lie strictly between zero and one.')


def require_private_paths(config):
    for key in ('image_data_root', 'manifest', 'metadata_root'):
        if not config['paths'].get(key):
            raise ValueError(f'Set paths.{key} in your private configuration.')
        if not Path(config['paths'][key]).exists():
            raise FileNotFoundError(f'Configured paths.{key} does not exist.')


def require_threshold_policy(config):
    for key in ('specificity_weight', 'minimum_specificity'):
        if config['evaluation']['threshold'].get(key) is None:
            raise ValueError(f'Set evaluation.threshold.{key} before training; the manuscript omits its value.')


def with_output_root(config, output_root):
    result = deepcopy(config)
    p = Path(output_root).expanduser()
    result['paths']['output_root'] = str((PROJECT_ROOT / p).resolve())
    return result
