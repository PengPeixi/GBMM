from __future__ import annotations

import math

import dgl.function as fn
import torch
import torch.nn as nn
import torch.nn.functional as F


def _src_dot_dst(source_field: str, destination_field: str, output_field: str):
    def function(edges):
        return {output_field: edges.src[source_field] * edges.dst[destination_field]}

    return function


def _scaling(field: str, scale_constant: float):
    def function(edges):
        return {field: edges.data[field] / scale_constant}

    return function


def _implicit_explicit_attention(implicit_attention: str, explicit_edge: str):
    def function(edges):
        return {implicit_attention: edges.data[implicit_attention] * edges.data[explicit_edge]}

    return function


def _out_edge_features(edge_feature: str):
    def function(edges):
        return {"e_out": edges.data[edge_feature]}

    return function


def _exponentiate(field: str):
    def function(edges):
        return {field: torch.exp(edges.data[field].sum(-1, keepdim=True).clamp(-5, 5))}

    return function


class MultiHeadAttentionLayer(nn.Module):
    """Original edge-modulated graph multi-head attention."""

    def __init__(self, in_dim: int, out_dim: int, num_heads: int, use_bias: bool):
        super().__init__()
        self.out_dim = out_dim
        self.num_heads = num_heads
        self.Q = nn.Linear(in_dim, out_dim * num_heads, bias=use_bias)
        self.K = nn.Linear(in_dim, out_dim * num_heads, bias=use_bias)
        self.V = nn.Linear(in_dim, out_dim * num_heads, bias=use_bias)
        self.proj_e = nn.Linear(in_dim, out_dim * num_heads, bias=use_bias)

    def propagate_attention(self, graph) -> None:
        graph.apply_edges(_src_dot_dst("K_h", "Q_h", "score"))
        graph.apply_edges(_scaling("score", math.sqrt(self.out_dim)))
        graph.apply_edges(_implicit_explicit_attention("score", "proj_e"))
        graph.apply_edges(_out_edge_features("score"))
        graph.apply_edges(_exponentiate("score"))
        edge_ids = graph.edges()
        graph.send_and_recv(
            edge_ids,
            fn.u_mul_e("V_h", "score", "V_h"),
            fn.sum("V_h", "wV"),
        )
        graph.send_and_recv(
            edge_ids,
            fn.copy_e("score", "score"),
            fn.sum("score", "z"),
        )

    def forward(self, graph, nodes, edges):
        graph.ndata["Q_h"] = self.Q(nodes).view(-1, self.num_heads, self.out_dim)
        graph.ndata["K_h"] = self.K(nodes).view(-1, self.num_heads, self.out_dim)
        graph.ndata["V_h"] = self.V(nodes).view(-1, self.num_heads, self.out_dim)
        graph.edata["proj_e"] = self.proj_e(edges).view(-1, self.num_heads, self.out_dim)
        self.propagate_attention(graph)
        node_output = graph.ndata["wV"] / (
            graph.ndata["z"] + torch.full_like(graph.ndata["z"], 1e-6)
        )
        return node_output, graph.edata["e_out"]


class GraphTransformerLayer(nn.Module):
    """Operator-for-operator restoration of the original GBMM graph layer."""

    def __init__(
        self,
        in_dim: int,
        out_dim: int,
        num_heads: int,
        dropout: float = 0.0,
        layer_norm: bool = False,
        batch_norm: bool = True,
        residual: bool = True,
        use_bias: bool = False,
    ):
        super().__init__()
        if out_dim % num_heads:
            raise ValueError("out_dim must be divisible by num_heads")
        if residual and in_dim != out_dim:
            raise ValueError("Residual GBMM graph layers require in_dim == out_dim")
        self.in_channels = in_dim
        self.out_channels = out_dim
        self.num_heads = num_heads
        self.dropout = dropout
        self.residual = residual
        self.layer_norm = layer_norm
        self.batch_norm = batch_norm
        self.attention = MultiHeadAttentionLayer(
            in_dim, out_dim // num_heads, num_heads, use_bias
        )
        self.O_h = nn.Linear(out_dim, out_dim)
        self.O_e = nn.Linear(out_dim, out_dim)
        if layer_norm:
            self.layer_norm1_h = nn.LayerNorm(out_dim)
            self.layer_norm1_e = nn.LayerNorm(out_dim)
        if batch_norm:
            self.batch_norm1_h = nn.BatchNorm1d(out_dim)
            self.batch_norm1_e = nn.BatchNorm1d(out_dim)
        self.FFN_h_layer1 = nn.Linear(out_dim, out_dim * 2)
        self.FFN_h_layer2 = nn.Linear(out_dim * 2, out_dim)
        self.FFN_e_layer1 = nn.Linear(out_dim, out_dim * 2)
        self.FFN_e_layer2 = nn.Linear(out_dim * 2, out_dim)
        if layer_norm:
            self.layer_norm2_h = nn.LayerNorm(out_dim)
            self.layer_norm2_e = nn.LayerNorm(out_dim)
        if batch_norm:
            self.batch_norm2_h = nn.BatchNorm1d(out_dim)
            self.batch_norm2_e = nn.BatchNorm1d(out_dim)

    def forward(self, graph, nodes, edges):
        nodes_input = nodes
        edges_input = edges
        nodes, edges = self.attention(graph, nodes, edges)
        nodes = F.dropout(nodes.view(-1, self.out_channels), self.dropout, training=self.training)
        edges = F.dropout(edges.view(-1, self.out_channels), self.dropout, training=self.training)
        nodes = self.O_h(nodes)
        edges = self.O_e(edges)
        if self.residual:
            nodes = nodes_input + nodes
            edges = edges_input + edges
        if self.layer_norm:
            nodes = self.layer_norm1_h(nodes)
            edges = self.layer_norm1_e(edges)
        if self.batch_norm:
            nodes = self.batch_norm1_h(nodes)
            edges = self.batch_norm1_e(edges)

        nodes_input = nodes
        edges_input = edges
        nodes = self.FFN_h_layer2(
            F.dropout(F.relu(self.FFN_h_layer1(nodes)), self.dropout, training=self.training)
        )
        edges = self.FFN_e_layer2(
            F.dropout(F.relu(self.FFN_e_layer1(edges)), self.dropout, training=self.training)
        )
        if self.residual:
            nodes = nodes_input + nodes
            edges = edges_input + edges
        if self.layer_norm:
            nodes = self.layer_norm2_h(nodes)
            edges = self.layer_norm2_e(edges)
        if self.batch_norm:
            nodes = self.batch_norm2_h(nodes)
            edges = self.batch_norm2_e(edges)
        return nodes, edges

    def __repr__(self) -> str:
        return "{}(in_channels={}, out_channels={}, heads={}, residual={})".format(
            self.__class__.__name__,
            self.in_channels,
            self.out_channels,
            self.num_heads,
            self.residual,
        )
