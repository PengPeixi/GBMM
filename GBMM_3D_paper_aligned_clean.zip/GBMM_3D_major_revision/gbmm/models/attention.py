from __future__ import annotations

import copy
import math

import torch
import torch.nn as nn
import torch.nn.functional as F


def clones(module: nn.Module, number: int) -> nn.ModuleList:
    """Produce independent copies exactly as in the original GBMM project."""
    return nn.ModuleList([copy.deepcopy(module) for _ in range(number)])


def scaled_dot_product_attention(query, key, value, mask=None, dropout=None):
    head_dim = query.size(-1)
    scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(head_dim)
    if mask is not None:
        scores = scores.masked_fill(mask == 0, -1e9)
    weights = F.softmax(scores, dim=-1)
    if dropout is not None:
        weights = dropout(weights)
    return torch.matmul(weights, value), weights


class MultiHeadedAttention(nn.Module):
    """Original four-linear-projection GBMM self/cross-attention block."""

    def __init__(self, heads: int, model_dim: int, dropout: float = 0.1):
        super().__init__()
        if model_dim % heads:
            raise ValueError("model_dim must be divisible by heads")
        self.d_k = model_dim // heads
        self.h = heads
        self.linears = clones(nn.Linear(model_dim, model_dim), 4)
        self.attn = None
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, query, key, value, mask=None):
        if mask is not None:
            mask = mask.unsqueeze(1)
        batch_size = query.size(0)
        query, key, value = [
            linear(tensor).view(batch_size, -1, self.h, self.d_k).transpose(1, 2)
            for linear, tensor in zip(self.linears, (query, key, value))
        ]
        output, self.attn = scaled_dot_product_attention(
            query, key, value, mask=mask, dropout=self.dropout
        )
        output = output.transpose(1, 2).contiguous().view(batch_size, -1, self.h * self.d_k)
        return self.linears[-1](output)


class MLPReadout(nn.Module):
    """Original two-hidden-layer GBMM readout: D -> D/2 -> D/4 -> classes."""

    def __init__(self, input_dim: int, output_dim: int, layers: int = 2):
        super().__init__()
        layer_list = [
            nn.Linear(input_dim // (2 ** level), input_dim // (2 ** (level + 1)), bias=True)
            for level in range(layers)
        ]
        layer_list.append(nn.Linear(input_dim // (2 ** layers), output_dim, bias=True))
        self.FC_layers = nn.ModuleList(layer_list)
        self.L = layers

    def forward(self, tensor):
        output = tensor
        for level in range(self.L):
            output = F.relu(self.FC_layers[level](output))
        return self.FC_layers[self.L](output)
