from __future__ import annotations

from typing import Mapping, Tuple

import dgl
import numpy as np
import torch
import torch.nn as nn

from .attention import MLPReadout, MultiHeadedAttention
from .graph_transformer import GraphTransformerLayer


ARCHITECTURE_CONTRACT = "gbmm_paper_training_v1"


def six_neighbor_edges(grid: Tuple[int, int, int]):
    """Original 3D six-neighbour graph construction."""
    height, width, depth = grid
    indices = np.arange(height * width * depth).reshape(height, width, depth)
    sources, destinations = [], []
    for height_index in range(height):
        for width_index in range(width):
            for depth_index in range(depth):
                current = int(indices[height_index, width_index, depth_index])
                for height_delta, width_delta, depth_delta in (
                    (-1, 0, 0),
                    (1, 0, 0),
                    (0, -1, 0),
                    (0, 1, 0),
                    (0, 0, -1),
                    (0, 0, 1),
                ):
                    neighbour = (
                        height_index + height_delta,
                        width_index + width_delta,
                        depth_index + depth_delta,
                    )
                    if all(0 <= value < limit for value, limit in zip(neighbour, grid)):
                        sources.append(current)
                        destinations.append(int(indices[neighbour]))
    return sources, destinations


class PatchEmbed(nn.Module):
    """Original Conv3d patch embedding used for both image and mask."""

    def __init__(self, patch_size: int, embed_dim: int, in_channels: int = 1):
        super().__init__()
        self.proj = nn.Conv3d(
            in_channels, embed_dim, kernel_size=patch_size, stride=patch_size, padding=0
        )
        self.norm = nn.Identity()

    def forward(self, tensor):
        return self.norm(self.proj(tensor).flatten(2).transpose(1, 2))


class GBMM3DBase(nn.Module):
    """Original graph, multimodal attention and Mamba backbone."""

    def __init__(self, model_config: Mapping):
        super().__init__()
        self.model_config = dict(model_config)
        self.pretrained_tabular_dim = int(model_config.get("pretrained_tabular_dim", 122))
        self.architecture_contract = ARCHITECTURE_CONTRACT
        if model_config.get("architecture", "original_3d_code_p3") != "original_3d_code_p3":
            raise ValueError("GBMM3D only supports the original_3d_code_p3 architecture")
        if model_config.get("tabular_fusion", "direct_outer_product") != "direct_outer_product":
            raise ValueError("GBMM3D requires direct_outer_product tabular fusion")

        image_size = int(model_config["image_size"])
        patch_size = int(model_config["patch_size"])
        hidden_dim = int(model_config["hidden_dim"])
        graph_heads = int(model_config["graph_heads"])
        graph_layers = int(model_config["graph_layers"])
        fusion_dim = int(model_config["fusion_dim"])
        cross_heads = int(model_config["cross_heads"])
        dropout = float(model_config["dropout"])
        layer_norm = bool(model_config["layer_norm"])
        batch_norm = bool(model_config["batch_norm"])

        if image_size % patch_size:
            raise ValueError("image_size must be divisible by patch_size")
        if self.pretrained_tabular_dim != 122:
            raise ValueError(
                "The retained backbone tabular width is exactly 122"
            )
        if fusion_dim != 122:
            raise ValueError(
                "fusion_dim must remain 122 in the retained backbone"
            )
        side = image_size // patch_size
        self.grid = (side, side, side)
        self.num_patches = side ** 3
        self.src_list, self.dst_list = six_neighbor_edges(self.grid)
        self.num_edges = len(self.src_list)

        # Preserve the original active graph and multimodal modules.
        self.layers = nn.ModuleList(
            [
                GraphTransformerLayer(
                    hidden_dim,
                    hidden_dim,
                    graph_heads,
                    dropout,
                    layer_norm,
                    batch_norm,
                    True,
                )
                for _ in range(graph_layers)
            ]
        )
        self.cross_layers = nn.ModuleList(
            [MultiHeadedAttention(cross_heads, fusion_dim) for _ in range(graph_layers)]
        )
        self.self_layers = nn.ModuleList(
            [MultiHeadedAttention(cross_heads, fusion_dim) for _ in range(graph_layers)]
        )
        self.proj_layers = nn.ModuleList(
            [nn.Linear(hidden_dim, fusion_dim) for _ in range(graph_layers)]
        )

        self.MLP_layer = MLPReadout(fusion_dim, int(model_config["num_classes"]))
        self.patch_embed = PatchEmbed(patch_size, hidden_dim, 1)
        self.patch_embed_mask = PatchEmbed(patch_size, hidden_dim, 1)
        self.MLP_layer_0 = nn.Linear(self.num_patches + 2, 1)
        self.epooling = nn.AdaptiveAvgPool2d((1, hidden_dim))
        self.hcpooling = nn.AdaptiveAvgPool2d((1, fusion_dim))
        self.eproj = nn.Linear(hidden_dim * 2, hidden_dim)

        # Keep the original fusion width; input feature dimensions are inferred.
        self.proj_clinical = nn.Linear(self.pretrained_tabular_dim, fusion_dim)
        self.pooling_proj = nn.Linear(hidden_dim, fusion_dim)
        self.pooling_proj_e = nn.Linear(hidden_dim, fusion_dim)
        self.pos_embed = nn.Parameter(torch.zeros(1, self.num_patches, hidden_dim))
        self.pos_embed_m = nn.Parameter(torch.zeros(1, self.num_patches, hidden_dim))

        from mambapy.mamba import Mamba, MambaConfig
        self.mamba = Mamba(
            MambaConfig(d_model=fusion_dim, n_layers=int(model_config["mamba_layers"]))
        )

    def _batched_graph(self, batch_size: int, device):
        graphs = [
            dgl.graph(
                (self.src_list, self.dst_list),
                num_nodes=self.num_patches,
                device=device,
            )
            for _ in range(batch_size)
        ]
        return dgl.batch(graphs)

    def forward_from_tabular122(self, images, masks, tabular_122):
        """Run the retained GBMM body from the projected tabular tensor."""
        if tabular_122.ndim != 2 or tabular_122.shape[1] != self.pretrained_tabular_dim:
            raise ValueError(
                "Expected tabular_122 shape "
                f"[batch, {self.pretrained_tabular_dim}], got {tuple(tabular_122.shape)}"
            )
        if images.ndim != 5 or masks.ndim != 5:
            raise ValueError("images and masks must both have shape [batch, channel, D, H, W]")
        if images.shape != masks.shape:
            raise ValueError(
                f"Image/mask tensor shape mismatch: {tuple(images.shape)} vs {tuple(masks.shape)}"
            )

        nodes_batch = self.patch_embed(images) + self.pos_embed
        masks_batch = self.patch_embed_mask(masks) + self.pos_embed_m
        if nodes_batch.shape[1] != self.num_patches:
            raise ValueError(
                f"Patch count is {nodes_batch.shape[1]}, expected {self.num_patches}"
            )
        batch_size = nodes_batch.shape[0]
        graph = self._batched_graph(batch_size, images.device)
        graph.ndata["feat"] = nodes_batch.reshape(-1, nodes_batch.shape[-1])
        source = torch.as_tensor(self.src_list, device=images.device)
        destination = torch.as_tensor(self.dst_list, device=images.device)
        edge_batches = [
            self.eproj(
                torch.cat(
                    (masks_batch[index, source], masks_batch[index, destination]), dim=-1
                )
            )
            for index in range(batch_size)
        ]
        graph.edata["feat"] = torch.cat(edge_batches, dim=0)
        nodes = graph.ndata["feat"]
        edges = graph.edata["feat"]

        clinical_interaction = torch.matmul(
            tabular_122.unsqueeze(-1), tabular_122.unsqueeze(-2)
        )
        clinical_hidden = self.proj_clinical(clinical_interaction)

        for graph_layer, self_attention, cross_attention, projection in zip(
            self.layers, self.self_layers, self.cross_layers, self.proj_layers
        ):
            nodes, edges = graph_layer(graph, nodes, edges)
            clinical_hidden = self_attention(
                clinical_hidden, clinical_hidden, clinical_hidden
            )
            clinical_hidden = cross_attention(
                projection(nodes.view(batch_size, self.num_patches, -1)),
                clinical_hidden,
                clinical_hidden,
            )

        edge_token = self.pooling_proj_e(
            self.epooling(edges.view(batch_size, self.num_edges, -1))
        )
        clinical_token = self.hcpooling(clinical_hidden)
        node_tokens = self.pooling_proj(
            nodes.view(batch_size, self.num_patches, -1)
        )
        sequence = torch.cat((node_tokens, edge_token, clinical_token), dim=1)
        sequence = self.mamba(sequence)
        # Pool the multimodal sequence before classification.
        embedding = self.MLP_layer_0(sequence.transpose(1, 2)).squeeze(-1)
        logits = self.MLP_layer(embedding)
        return logits, embedding


class GBMM3DStudent(GBMM3DBase):
    """Project the supplied radiomic and clinical features into the backbone."""

    def __init__(self, model_config: Mapping, radiomics_dim: int, clinical_dim: int):
        super().__init__(model_config)
        self.radiomics_dim = int(radiomics_dim)
        self.clinical_dim = int(clinical_dim)
        self.tabular_dim = self.radiomics_dim + self.clinical_dim
        hidden_dim = int(model_config.get("tabular_adapter_hidden_dim", 32))
        if hidden_dim <= 0:
            raise ValueError("tabular_adapter_hidden_dim must be positive")
        self.tabular_input_adapter = nn.Sequential(
            nn.Linear(self.tabular_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, self.pretrained_tabular_dim),
        )
        nn.init.xavier_uniform_(self.tabular_input_adapter[0].weight)
        nn.init.zeros_(self.tabular_input_adapter[0].bias)
        # Small but non-zero initialization avoids the zero-gradient point of
        # the immediately following x @ x^T interaction.
        nn.init.xavier_uniform_(self.tabular_input_adapter[2].weight, gain=0.1)
        nn.init.zeros_(self.tabular_input_adapter[2].bias)

    def forward(self, images, masks, radiomics, clinical):
        if radiomics.ndim != 2 or radiomics.shape[1] != self.radiomics_dim:
            raise ValueError(
                f"Expected radiomics shape [batch, {self.radiomics_dim}], got {tuple(radiomics.shape)}"
            )
        if clinical.ndim != 2 or clinical.shape[1] != self.clinical_dim:
            raise ValueError(
                f"Expected clinical shape [batch, {self.clinical_dim}], got {tuple(clinical.shape)}"
            )

        # Preserve feature order: radiomics followed by clinical variables.
        tabular = torch.cat((radiomics, clinical), dim=1)
        adapted_tabular_122 = self.tabular_input_adapter(tabular)
        return self.forward_from_tabular122(images, masks, adapted_tabular_122)


GBMM3D = GBMM3DStudent
