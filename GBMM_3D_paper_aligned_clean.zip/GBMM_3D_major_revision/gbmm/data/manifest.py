from __future__ import annotations
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping
import numpy as np
import pandas as pd


@dataclass(frozen=True)
class ManifestRecord:
    image_patient_id: str
    radiomics_patient_id: str
    clinical_patient_id: str
    split: str
    label: int
    scanner: str
    resolutions: Mapping[str, Mapping[str, str]]


def load_manifest(path):
    """Load a private JSON with a samples list; no patient data are bundled.

    Each item uses the original ManifestRecord fields. A resolution contains
    image_path and mask_path relative to image_data_root (or absolute paths).
    Optional derive_from='1mm' for 5mm asks the loader to simulate thick slices
    from that patient's 1mm image. Matching 5mm radiomics must still be supplied.
    The explicit clinical_patient_id replaces private ID mapping heuristics.
    """
    with Path(path).open(encoding='utf-8') as handle:
        payload = json.load(handle)
    records = [ManifestRecord(**item) for item in payload['samples']]
    for field in ('image_patient_id', 'radiomics_patient_id', 'clinical_patient_id'):
        ids = [getattr(r, field) for r in records]
        if any(not isinstance(x, str) or not x.strip() for x in ids):
            raise ValueError(f'{field} must contain explicit nonempty strings.')
        if len(ids) != len(set(ids)):
            raise ValueError(f'Duplicate {field}; patients must not cross cohorts.')
    for record in records:
        if record.split not in ('train', 'internal', 'external') or record.label not in (0, 1):
            raise ValueError('Invalid split or binary label in manifest.')
        required = ('1mm', '5mm') if record.split != 'external' else ('5mm',)
        for resolution in required:
            spec = record.resolutions.get(resolution, {})
            if spec.get('derive_from') == '1mm' and resolution == '5mm':
                spec = record.resolutions.get('1mm', {})
            if not spec.get('image_path') or not spec.get('mask_path'):
                raise ValueError(f'Missing {resolution} image/mask specification.')
    if not records:
        raise ValueError('Empty manifest.')
    return records


class FeatureRepository:
    """Load only requested cohorts; validate feature order and explicit IDs."""
    def __init__(self, config, records):
        self.config, self.records = config, list(records)
        self.metadata_root = Path(config['paths']['metadata_root'])
        self.radiomics, self.clinical = {}, {}
        self.radiomics_columns = self.clinical_columns = None
        self.preprocessing = None
        self._load_all()

    @staticmethod
    def _read_unique(path):
        frame = pd.read_csv(path, dtype={'patient_id': str})
        if 'patient_id' not in frame or frame['patient_id'].isna().any() or frame['patient_id'].duplicated().any():
            raise ValueError(f'Missing or duplicated patient_id column in {path.name}.')
        return frame

    def _table(self, path, records, id_field, excluded, expected):
        frame = self._read_unique(path)
        cols = [c for c in frame if c not in {'patient_id', 'label'} | set(excluded)]
        if not cols or (expected is not None and cols != expected):
            raise ValueError(f'Feature columns/order mismatch in {path.name}.')
        frame = frame.set_index('patient_id')
        ids = [getattr(r, id_field) for r in records]
        if not set(ids).issubset(frame.index):
            raise ValueError(f'Missing patient features in {path.name}.')
        selected = frame.loc[ids]
        values = selected[cols].to_numpy(np.float32)
        if not np.isfinite(values).all():
            raise ValueError(f'Features must be finite numeric values in {path.name}.')
        if 'label' in selected and not np.array_equal(selected['label'].to_numpy(), [r.label for r in records]):
            raise ValueError(f'Manifest/table label mismatch in {path.name}.')
        return cols, dict(zip(ids, values))

    def _load_all(self):
        for split in dict.fromkeys(r.split for r in self.records):
            records = self.records_for_split(split)
            resolutions = ('1mm', '5mm') if split == 'train' else self.config['evaluation']['resolutions'][split]
            for resolution in resolutions:
                path = self.metadata_root / self.config['data']['radiomics_file'].format(split=split, resolution=resolution)
                self.radiomics_columns, values = self._table(path, records, 'radiomics_patient_id', self.config['data']['radiomics_exclude_columns'], self.radiomics_columns)
                self.radiomics[(split, resolution)] = values
            path = self.metadata_root / self.config['data']['clinical_file'].format(split=split)
            self.clinical_columns, values = self._table(path, records, 'clinical_patient_id', [], self.clinical_columns)
            self.clinical[split] = values

    @property
    def radiomics_dim(self):
        return len(self.radiomics_columns)

    @property
    def clinical_dim(self):
        return len(self.clinical_columns)

    def fit_preprocessing(self, train_records):
        """For raw tables, fit fold-train-only z scores, separately by resolution."""
        if not train_records or any(r.split != 'train' for r in train_records):
            raise ValueError('Preprocessing can only be fitted to fold training records.')
        state = {'already_standardized': self.config['data']['features_already_standardized']}
        if not state['already_standardized']:
            def stats(values):
                array = np.stack(values).astype(np.float64)
                std = array.std(axis=0)
                return {'mean': array.mean(axis=0).tolist(), 'scale': np.where(std > 0, std, 1).tolist()}
            for res in ('1mm', '5mm'):
                state[res] = stats([self.radiomics[('train', res)][r.radiomics_patient_id] for r in train_records])
            state['clinical'] = stats([self.clinical['train'][r.clinical_patient_id] for r in train_records])
        self.set_preprocessing(state)
        return state

    def set_preprocessing(self, state):
        if state['already_standardized'] != self.config['data']['features_already_standardized']:
            raise ValueError('Input standardization mode differs from training.')
        self.preprocessing = state

    def get(self, record, resolution):
        if self.preprocessing is None:
            raise RuntimeError('Fit training preprocessing or load it from the fold checkpoint.')
        radiomics = self.radiomics[(record.split, resolution)][record.radiomics_patient_id].copy()
        clinical = self.clinical[record.split][record.clinical_patient_id].copy()
        if not self.preprocessing['already_standardized']:
            def normalize(value, key):
                s = self.preprocessing[key]
                return ((value - np.asarray(s['mean'])) / np.asarray(s['scale'])).astype(np.float32)
            radiomics, clinical = normalize(radiomics, resolution), normalize(clinical, 'clinical')
        return radiomics, clinical

    def records_for_split(self, split):
        return [r for r in self.records if r.split == split]
