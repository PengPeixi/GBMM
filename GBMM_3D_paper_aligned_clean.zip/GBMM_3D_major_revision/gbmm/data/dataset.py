from __future__ import annotations
from pathlib import Path
from typing import Mapping
import nibabel as nib
from nibabel.processing import resample_from_to, resample_to_output
import numpy as np
import torch
import torch.nn.functional as F
from monai.transforms import Resize, ScaleIntensityRange
from torch.utils.data import Dataset


class DeterministicGBMMTransform:
    """Physical resampling, ROI crop, HU normalization and 64-cubed input."""
    def __init__(self, config: Mapping):
        self.input_size = tuple(config['data']['input_size'])
        self.mask_threshold = float(config['data']['mask_threshold'])
        self.tolerance = float(config['data']['spacing_tolerance_mm'])
        self.scale = ScaleIntensityRange(
            a_min=config['data']['intensity_min'], a_max=config['data']['intensity_max'],
            b_min=0.0, b_max=1.0, clip=True,
        )
        self.resize = Resize(self.input_size, mode='trilinear', align_corners=False)

    def __call__(self, image_path: Path, mask_path: Path, resolution='1mm', derive=False):
        image, mask = nib.load(str(image_path)), nib.load(str(mask_path))
        if len(image.shape) != 3 or image.shape != mask.shape or not np.allclose(image.affine, mask.affine, atol=1e-4):
            raise ValueError('Image and mask must have matching 3D physical geometry.')
        image, mask = nib.as_closest_canonical(image), nib.as_closest_canonical(mask)
        expected = (1, 1, 1) if derive or resolution == '1mm' else (1, 1, 5)
        if not np.allclose(nib.affines.voxel_sizes(image.affine), expected, atol=self.tolerance, rtol=0):
            raise ValueError(f'Input spacing does not match expected {expected} mm.')
        # Work in floating point so interpolation cannot quantize CT intensities.
        image_values = image.get_fdata(dtype=np.float32)
        mask_values = mask.get_fdata(dtype=np.float32)
        if not np.isfinite(image_values).all() or not np.isfinite(mask_values).all():
            raise ValueError('Non-finite source image or mask.')
        image = nib.Nifti1Image(image_values, image.affine)
        mask = nib.Nifti1Image((mask_values > self.mask_threshold).astype(np.uint8), mask.affine)
        if derive:
            # 1mm -> 5mm uses the declared target spacing, not every-other-slice deletion.
            image = resample_to_output(image, voxel_sizes=(1, 1, 5), order=3, mode='nearest')
            mask = resample_from_to(mask, image, order=0, mode='constant', cval=0)
        if resolution == '5mm':
            # Supplement: upsample the thick-slice volume to 1mm before network input.
            image = resample_to_output(image, voxel_sizes=(1, 1, 1), order=1, mode='nearest')
            mask = resample_from_to(mask, image, order=0, mode='constant', cval=0)
        array = image.get_fdata(dtype=np.float32)
        mask_array = mask.get_fdata(dtype=np.float32)
        if not np.isfinite(array).all() or not np.isfinite(mask_array).all():
            raise ValueError('Non-finite image or mask.')
        coords = np.where(mask_array > self.mask_threshold)
        if not coords[0].size:
            raise ValueError('Empty ROI after physical resampling.')
        box = tuple(slice(int(axis.min()), int(axis.max()) + 1) for axis in coords)
        array, mask_array = array[box].copy(), mask_array[box].copy()
        # Preserve the original network tensor convention: (X,Y,Z) -> (C,Z,X,Y).
        image_tensor = torch.from_numpy(array).unsqueeze(0).permute(0, 3, 1, 2)
        mask_tensor = torch.from_numpy(mask_array).unsqueeze(0).permute(0, 3, 1, 2)
        image_tensor = self.resize(self.scale(image_tensor))
        mask_tensor = F.interpolate(mask_tensor.unsqueeze(0), size=self.input_size, mode='nearest').squeeze(0)
        mask_tensor = (mask_tensor > self.mask_threshold).float()
        if not mask_tensor.any():
            raise ValueError('Empty ROI after input resizing.')
        return image_tensor, mask_tensor


class GBMMDataset(Dataset):
    """One resolution per item with matching radiomics and shared clinical features."""
    def __init__(self, records, resolution, repository, config):
        if resolution not in ('1mm', '5mm'):
            raise ValueError('Unsupported input resolution.')
        self.records, self.resolution = list(records), resolution
        self.repository = repository
        self.data_root = Path(config['paths']['image_data_root'])
        self.transform = DeterministicGBMMTransform(config)

    def __len__(self):
        return len(self.records)

    def __getitem__(self, index):
        record = self.records[index]
        paths = record.resolutions[self.resolution]
        derive = paths.get('derive_from') == '1mm'
        if derive:
            paths = record.resolutions['1mm']
        image, mask = self.transform(self.data_root / paths['image_path'], self.data_root / paths['mask_path'], self.resolution, derive)
        radiomics, clinical = self.repository.get(record, self.resolution)
        return {
            'image': image, 'mask': mask,
            'radiomics': torch.from_numpy(radiomics), 'clinical': torch.from_numpy(clinical),
            'label': torch.tensor(record.label, dtype=torch.long),
            'patient_id': record.image_patient_id, 'scanner': record.scanner,
            'resolution': self.resolution,
        }
