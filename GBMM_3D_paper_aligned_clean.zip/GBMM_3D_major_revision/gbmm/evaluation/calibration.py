"""Calibration assessment only: never transform saved prediction probabilities."""
import numpy as np
import pandas as pd
from scipy.special import expit, logit
from sklearn.linear_model import LogisticRegression


def calibration_curves(frame, iterations, seed, bins=10):
    """A fixed-prediction logistic calibration-curve estimator with bootstrap bias correction.

    The correction is 2 * apparent - mean(bootstrap curve), clipped to [0,1].
    This corrects bootstrap estimator bias; it is NOT retraining optimism correction
    for the GBMM network and is NOT Platt postprocessing of patient predictions.
    """
    y, p = frame.label.to_numpy(int), frame.probability.to_numpy(float)
    if set(y) != {0, 1}:
        raise ValueError('Calibration assessment needs both classes.')
    grid = np.linspace(max(1e-6, p.min()), min(1-1e-6, p.max()), 101)
    if grid[0] > grid[-1]:
        grid = np.full(101, np.clip(p[0], 1e-6, 1-1e-6))
    x = logit(np.clip(p, 1e-6, 1-1e-6)).reshape(-1, 1)
    gx = logit(grid).reshape(-1, 1)
    def fit_curve(index):
        model = LogisticRegression(C=1e6, solver='lbfgs', max_iter=2000)
        model.fit(x[index], y[index])
        return expit(model.intercept_[0] + model.coef_[0, 0] * gx[:, 0])
    apparent = fit_curve(np.arange(len(y)))
    rng = np.random.default_rng(seed)
    positive, negative = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    samples = np.stack([fit_curve(np.concatenate((rng.choice(positive, len(positive)), rng.choice(negative, len(negative))))) for _ in range(iterations)])
    curves = pd.DataFrame({'predicted_probability': grid, 'apparent': apparent,
                           'bootstrap_estimator_bias_corrected': np.clip(2 * apparent - samples.mean(axis=0), 0, 1),
                           'bootstrap_lower_95': np.quantile(samples, .025, axis=0),
                           'bootstrap_upper_95': np.quantile(samples, .975, axis=0)})
    boundaries = np.linspace(0, 1, bins + 1)
    index = np.clip(np.digitize(p, boundaries) - 1, 0, bins - 1)
    points = [{'bin': int(b), 'n': int((index == b).sum()), 'predicted_mean': float(p[index == b].mean()),
               'observed_fraction': float(y[index == b].mean())} for b in range(bins) if (index == b).any()]
    return curves, pd.DataFrame(points)
