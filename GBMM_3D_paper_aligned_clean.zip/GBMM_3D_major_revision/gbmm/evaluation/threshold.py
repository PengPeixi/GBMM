from __future__ import annotations
import numpy as np
from sklearn.metrics import roc_curve

TRAINING_OOF_SOURCE = 'training_oof_only'


def select_oof_threshold(labels, probabilities, specificity_weight, minimum_specificity):
    """Maximize sensitivity + w*specificity - 1 subject to specificity >= s.

    Both policy parameters must be prespecified, independently of test outcomes.
    Equal objectives are resolved by higher sensitivity, then higher specificity,
    then the higher threshold. The same frozen operating point serves all cohorts.
    """
    y, p = np.asarray(labels), np.asarray(probabilities, dtype=float)
    if y.ndim != 1 or p.ndim != 1 or y.size == 0 or y.shape != p.shape:
        raise ValueError('OOF arrays must be nonempty, one-dimensional and aligned.')
    if set(np.unique(y)) != {0, 1} or not np.isfinite(p).all() or np.any((p < 0) | (p > 1)):
        raise ValueError('OOF selection requires both classes and valid probabilities.')
    if specificity_weight is None or minimum_specificity is None:
        raise ValueError('Prespecify specificity_weight and minimum_specificity.')
    if not np.isfinite(specificity_weight) or specificity_weight <= 0 or not 0 <= minimum_specificity <= 1:
        raise ValueError('Invalid threshold policy.')
    fpr, tpr, thresholds = roc_curve(y, p, drop_intermediate=False)
    # Include the predict-none operating point with a finite, explicit cutoff.
    thresholds[0] = np.nextafter(float(p.max()), np.inf)
    specificity = 1 - fpr
    objective = tpr + specificity_weight * specificity - 1
    eligible = np.flatnonzero(specificity >= minimum_specificity)
    if not eligible.size:
        raise ValueError('No cutoff satisfies the prespecified specificity constraint.')
    best_score = objective[eligible].max()
    tied = eligible[np.isclose(objective[eligible], best_score, atol=1e-12, rtol=0)]
    best = max(tied, key=lambda i: (tpr[i], specificity[i], thresholds[i]))
    return {
        'source': TRAINING_OOF_SOURCE, 'threshold': float(thresholds[best]),
        'method': 'specificity_constrained_weighted_youden',
        'formula': 'sensitivity + specificity_weight * specificity - 1',
        'specificity_weight': float(specificity_weight),
        'minimum_specificity': float(minimum_specificity),
        'weighted_youden': float(objective[best]), 'sensitivity': float(tpr[best]),
        'specificity': float(specificity[best]), 'n_patients': int(len(y)),
        'predict_none': bool(thresholds[best] > p.max()),
    }
