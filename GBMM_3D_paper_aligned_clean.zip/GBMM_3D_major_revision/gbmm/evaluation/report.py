from pathlib import Path
import numpy as np
import pandas as pd
from .bootstrap import stratified_bootstrap
from .calibration import calibration_curves
from .dca import decision_curve
from .delong import paired_delong
from .metrics import binary_metrics
from gbmm.prediction import load_run
from gbmm.utils.io import atomic_csv_dump, ensure_dir


def dca_with_intervals(frame, config):
    e = config['evaluation']
    result = decision_curve(frame, 'test', e['dca_threshold_min'], e['dca_threshold_max'], e['dca_threshold_step'])
    thresholds = result.threshold.to_numpy()
    odds = thresholds / (1 - thresholds)
    y, p = frame.label.to_numpy(), frame.probability.to_numpy()
    rng = np.random.default_rng(e['bootstrap_seed'])
    positive, negative = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    samples = []
    for _ in range(e['bootstrap_iterations']):
        idx = np.concatenate((rng.choice(positive, len(positive)), rng.choice(negative, len(negative))))
        decision = p[idx, None] >= thresholds[None, :]
        samples.append(((decision & (y[idx, None] == 1)).sum(axis=0) - (decision & (y[idx, None] == 0)).sum(axis=0) * odds) / len(idx))
    result['lower_95'], result['upper_95'] = np.quantile(samples, [.025, .975], axis=0)
    return result.drop(columns='cohort')


def generate_evaluation_outputs(config, baseline_predictions=None):
    output = Path(config['paths']['output_root'])
    complete, frozen, _ = load_run(output)
    target = ensure_dir(output / 'evaluation')
    threshold = frozen['threshold']
    summaries, comparisons = [], []
    baseline = None
    if baseline_predictions:
        baseline = pd.read_csv(baseline_predictions, dtype={'patient_id': str})
        required = {'patient_id', 'label', 'cohort', 'resolution', 'model', 'probability'}
        if not required.issubset(baseline.columns) or baseline.empty:
            raise ValueError('Baseline CSV needs patient_id,label,cohort,resolution,model,probability.')
        if baseline.duplicated(['cohort', 'resolution', 'model', 'patient_id']).any():
            raise ValueError('Duplicate baseline prediction rows.')
        valid = {(c, r) for c, rs in config['evaluation']['resolutions'].items() for r in rs}
        if not set(zip(baseline.cohort, baseline.resolution)).issubset(valid):
            raise ValueError('Baseline CSV contains unsupported cohort/resolution pairs.')
    for cohort, resolutions in config['evaluation']['resolutions'].items():
        for resolution in resolutions:
            frame = pd.read_csv(output / f'{cohort}_predictions_{resolution}.csv', dtype={'patient_id': str})
            if frame.empty or frame.patient_id.duplicated().any() or not (frame.run_id == complete['run_id']).all():
                raise ValueError('Invalid or stale prediction file.')
            if not (frame.cohort == cohort).all() or not (frame.resolution == resolution).all() or not np.allclose(frame.threshold, threshold, atol=1e-14, rtol=0):
                raise ValueError('Prediction cohort/resolution/threshold mismatch.')
            p = frame.probability.to_numpy(float)
            if not np.isfinite(p).all() or ((p < 0) | (p > 1)).any() or set(frame.label) != {0, 1}:
                raise ValueError('Reports require both classes and finite probabilities.')
            e = config['evaluation']
            metrics = binary_metrics(frame.label, frame.probability, threshold)
            boot = stratified_bootstrap(frame, cohort, threshold, e['bootstrap_iterations'], e['bootstrap_seed'], resolution=resolution)
            for key in ('auc', 'accuracy', 'sensitivity', 'specificity', 'ppv', 'npv', 'brier'):
                samples = boot[key].dropna()
                metrics[f'{key}_lower_95'] = samples.quantile(.025)
                metrics[f'{key}_upper_95'] = samples.quantile(.975)
            metrics.update({'cohort': cohort, 'resolution': resolution})
            summaries.append(metrics)
            stem = f'{cohort}_{resolution}'
            atomic_csv_dump(boot, target / f'{stem}_bootstrap.csv')
            curves, bins = calibration_curves(frame, e['bootstrap_iterations'], e['bootstrap_seed'], e['calibration_bins'])
            atomic_csv_dump(curves, target / f'{stem}_calibration_curve.csv')
            atomic_csv_dump(bins, target / f'{stem}_calibration_bins.csv')
            atomic_csv_dump(dca_with_intervals(frame, config), target / f'{stem}_dca.csv')
            if baseline is not None:
                part = baseline[(baseline.cohort == cohort) & (baseline.resolution == resolution)]
                for model_name, model in part.groupby('model'):
                    paired = frame[['patient_id', 'label', 'probability']].merge(model[['patient_id', 'label', 'probability']], on=['patient_id', 'label'], validate='one_to_one', suffixes=('_gbmm', '_baseline'))
                    if len(paired) != len(frame) or len(paired) != len(model):
                        raise ValueError('Paired DeLong requires exactly the same patients and labels.')
                    comparison = paired_delong(paired.label, paired.probability_gbmm, paired.probability_baseline)
                    comparisons.append({'cohort': cohort, 'resolution': resolution, 'baseline': model_name, **comparison})
    atomic_csv_dump(pd.DataFrame(summaries), target / 'metrics_with_95ci.csv')
    # Always refresh this file, including an empty table when no baselines were supplied.
    columns = ['cohort', 'resolution', 'baseline', 'gbmm_auc', 'baseline_auc', 'auc_difference', 'variance', 'p_value', 'degenerate_variance']
    atomic_csv_dump(pd.DataFrame(comparisons, columns=columns), target / 'paired_delong.csv')
    return pd.DataFrame(summaries)
