import numpy as np
from scipy.stats import norm


def paired_delong(labels, first, second):
    """Paired DeLong covariance from case/control placement values; ties get 0.5."""
    y, p, q = np.asarray(labels), np.asarray(first, float), np.asarray(second, float)
    if y.ndim != 1 or y.shape != p.shape or p.shape != q.shape or set(y) != {0, 1}:
        raise ValueError('Paired aligned binary labels and predictions are required.')
    if not np.isfinite(p).all() or not np.isfinite(q).all() or ((p < 0) | (p > 1) | (q < 0) | (q > 1)).any():
        raise ValueError('Invalid probabilities for paired DeLong.')
    positive, negative = y == 1, y == 0
    m, n = positive.sum(), negative.sum()
    if min(m, n) < 2:
        raise ValueError('DeLong requires at least two patients in each class.')
    v10, v01, aucs = [], [], []
    for score in (p, q):
        delta = score[positive, None] - score[None, negative]
        placement = (delta > 0).astype(float) + 0.5 * (delta == 0)
        v10.append(placement.mean(axis=1)); v01.append(placement.mean(axis=0)); aucs.append(placement.mean())
    covariance = np.cov(v10, ddof=1) / m + np.cov(v01, ddof=1) / n
    contrast = np.array([1., -1.])
    variance = max(0., float(contrast @ covariance @ contrast))
    difference = float(aucs[0] - aucs[1])
    if variance == 0:
        # A zero estimated variance with unequal AUCs does not identify a valid z test.
        pvalue = 1.0 if difference == 0 else float('nan')
    else:
        pvalue = float(2 * norm.sf(abs(difference) / np.sqrt(variance)))
    return {'gbmm_auc': float(aucs[0]), 'baseline_auc': float(aucs[1]), 'auc_difference': difference,
            'variance': variance, 'p_value': pvalue, 'degenerate_variance': variance == 0}
