from __future__ import annotations

import numpy as np
import pandas as pd


def decision_curve(
    frame: pd.DataFrame,
    cohort: str,
    minimum: float,
    maximum: float,
    step: float,
    probability_column: str = "probability",
    **metadata,
) -> pd.DataFrame:
    labels = frame["label"].to_numpy(dtype=int)
    probabilities = frame[probability_column].to_numpy(dtype=float)
    n = len(frame)
    prevalence = labels.mean()
    rows = []
    for threshold in np.arange(minimum, maximum + step / 2.0, step):
        predictions = probabilities >= threshold
        true_positive = int(np.sum(predictions & (labels == 1)))
        false_positive = int(np.sum(predictions & (labels == 0)))
        odds = threshold / (1.0 - threshold)
        rows.append(
            {
                "cohort": cohort,
                **metadata,
                "threshold": float(threshold),
                "model_net_benefit": float(true_positive / n - false_positive / n * odds),
                "treat_all_net_benefit": float(prevalence - (1.0 - prevalence) * odds),
                "treat_none_net_benefit": 0.0,
            }
        )
    return pd.DataFrame(rows)
