from __future__ import annotations

from typing import List

import numpy as np
import pandas as pd

from .metrics import binary_metrics


def stratified_bootstrap(
    frame: pd.DataFrame,
    cohort: str,
    threshold: float,
    iterations: int,
    seed: int,
    probability_column: str = "probability",
    **metadata,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    positive = frame.index[frame["label"] == 1].to_numpy()
    negative = frame.index[frame["label"] == 0].to_numpy()
    if not len(positive) or not len(negative):
        return pd.DataFrame()
    rows: List[dict] = []
    for iteration in range(iterations):
        selected = np.concatenate(
            (rng.choice(positive, len(positive), replace=True), rng.choice(negative, len(negative), replace=True))
        )
        sampled = frame.loc[selected]
        metrics = binary_metrics(sampled["label"], sampled[probability_column], threshold)
        metrics.update({"cohort": cohort, "bootstrap_iteration": iteration, **metadata})
        rows.append(metrics)
    return pd.DataFrame(rows)
