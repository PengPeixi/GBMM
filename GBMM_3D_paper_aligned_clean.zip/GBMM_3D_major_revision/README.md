# GBMM 3D

## 环境配置

Linux x86_64、NVIDIA GPU、支持 CUDA 12.1 的驱动，Python 3.12。进入解压后的工程目录执行：

```bash
conda create -n gbmm python=3.12 -y
conda activate gbmm
python -m pip install --upgrade pip
python -m pip install torch==2.4.1 --index-url https://download.pytorch.org/whl/cu121
python -m pip install "dgl==2.4.0+cu121" -f https://data.dgl.ai/wheels/torch-2.4/cu121/repo.html
python -m pip install -r requirements.txt
python -m pip install -e . --no-deps
python -c "import torch, dgl, monai, mambapy; print(torch.__version__, dgl.__version__, torch.cuda.is_available())"
```

安装源：[PyTorch 官方说明](https://pytorch.org/get-started/previous-versions/)、[DGL 官方安装说明](https://www.dgl.ai/pages/start.html)。

## 训练

先在 `config/default.yaml` 填写三个私有输入路径，以及事先确定的 `specificity_weight` 和 `minimum_specificity`。原工程已标准化特征表可沿用默认文件模板；如果输入未经标准化的特征表，修改模板并设置 `features_already_standardized: false`。文件格式见数据加载接口的注释。工程不包含数据和权重。

```bash
python -m scripts.train --config config/default.yaml --device cuda:0
```

## 测试

完成训练后执行下列命令，测试内部与外部队列；结果写入工程下 `outputs/full/`。

```bash
python -m scripts.test --config config/default.yaml --device cuda:0
```

若需同时做配对 DeLong 比较：

```bash
python -m scripts.test --config config/default.yaml --device cuda:0 --baseline-predictions /path/to/private/baseline_predictions.csv
```
