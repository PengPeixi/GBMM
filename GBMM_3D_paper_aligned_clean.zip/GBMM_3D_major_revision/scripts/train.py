from __future__ import annotations
import argparse
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
from gbmm.config import load_config, require_private_paths, require_threshold_policy, with_output_root


def main():
    parser = argparse.ArgumentParser(description='Train GBMM: five folds, 40 epochs, cyclic 1mm/5mm, EMA teacher.')
    parser.add_argument('--config', default='config/default.yaml')
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--output-root', default='')
    args = parser.parse_args()
    config = load_config(args.config)
    if args.output_root:
        config = with_output_root(config, args.output_root)
    require_private_paths(config)
    require_threshold_policy(config)
    from gbmm.training.engine import run_cross_validation
    run_cross_validation(config, args.device)


if __name__ == '__main__':
    main()
