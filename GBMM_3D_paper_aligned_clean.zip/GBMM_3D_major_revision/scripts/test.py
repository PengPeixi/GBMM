from __future__ import annotations
import argparse
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
from gbmm.config import load_config, require_private_paths, with_output_root


def main():
    parser = argparse.ArgumentParser(description='Test five EMA teachers on internal/external cohorts and report metrics.')
    parser.add_argument('--config', default='config/default.yaml')
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--output-root', default='')
    parser.add_argument('--baseline-predictions', default='', help='Optional private CSV for paired DeLong tests.')
    args = parser.parse_args()
    config = load_config(args.config)
    if args.output_root:
        config = with_output_root(config, args.output_root)
    require_private_paths(config)
    from gbmm.prediction import predict_ensemble
    from gbmm.evaluation.report import generate_evaluation_outputs
    predict_ensemble(config, 'internal', args.device)
    predict_ensemble(config, 'external', args.device)
    summary = generate_evaluation_outputs(config, args.baseline_predictions or None)
    print(summary.to_string(index=False))


if __name__ == '__main__':
    main()
